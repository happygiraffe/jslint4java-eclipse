// A stub JSLINT that returns no errors.
function JSLINT(source, options) {
    JSLINT.errors = [];
    return true;
}
