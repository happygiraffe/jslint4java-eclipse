function JSLINT(source, options) {
  JSLINT.errors = [
    {
      line: 1,
      character: 1,
      reason: "I don't like you",
      evidence: "eWeWeWeWeWe"
    }
  ];
  return false;
}