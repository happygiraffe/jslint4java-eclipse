function info(str) {
  // …log somehow…
}

var foo = '1';
if (foo === '0') {
    info('is zero')
}