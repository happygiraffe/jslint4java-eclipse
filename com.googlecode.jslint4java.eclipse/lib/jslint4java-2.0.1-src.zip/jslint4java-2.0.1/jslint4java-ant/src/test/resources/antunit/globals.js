foo(bar(42));
