var answer = 42;
