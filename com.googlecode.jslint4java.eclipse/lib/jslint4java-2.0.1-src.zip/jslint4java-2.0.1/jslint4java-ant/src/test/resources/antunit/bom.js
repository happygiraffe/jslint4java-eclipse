﻿// This file starts with a UTF-8 BOM.
alert("Hello BOM");
