(function () {
    "use strict";
    var cfg = {'1': {'id': 1,
                     'fields': {}},
               '2': {'id': 2,
                     'parentId': 1,
                     'fields': {'3': {'id': 3}}}};
}());
