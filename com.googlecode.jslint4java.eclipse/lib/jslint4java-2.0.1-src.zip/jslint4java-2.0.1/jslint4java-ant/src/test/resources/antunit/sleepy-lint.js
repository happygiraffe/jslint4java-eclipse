// Never return.
function JSLINT(source, options) {
  var x;
  while (1) {
      x = x + 1;
  }
}