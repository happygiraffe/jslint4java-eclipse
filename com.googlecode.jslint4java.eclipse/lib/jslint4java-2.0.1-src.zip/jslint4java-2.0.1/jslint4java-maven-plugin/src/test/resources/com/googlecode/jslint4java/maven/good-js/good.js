var foo = 42;
function bar() {
    var baz = 24;
}