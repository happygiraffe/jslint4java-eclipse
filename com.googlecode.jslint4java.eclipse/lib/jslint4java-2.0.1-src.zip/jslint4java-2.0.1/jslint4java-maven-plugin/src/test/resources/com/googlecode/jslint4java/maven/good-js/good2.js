/*
 * This is present in order to test reporting of multiple files.
 */

function x() {
    return x();
}