// Always succeeds.  Do not use, only for testing.
function JSLINT(source, options) {
  JSLINT.errors = [];
  return true;
}
